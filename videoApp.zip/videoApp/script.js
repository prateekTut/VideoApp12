// script.js
document.addEventListener("DOMContentLoaded", function () {
  const categoryButtons = document.getElementById("category-buttons");
  const videoContainer = document.getElementById("video-container");
  const videoCardTemplate = document.getElementById("video-card-template");

  const categories = ["Action", "Comedy", "Drama", "Documentary"];
  const videoData = {
    Action: [
      {
        title: "Epic Car Chase",
        src: "https://www.youtube.com/watch?v=6XMuUVw7TOM",
      },
      {
        title: "Superhero Battle",
        src: "https://www.youtube.com/watch?v=FkTybqcX-Yo",
      },
      {
        title: "Spy Mission",
        src: "https://www.youtube.com/watch?v=U9FzgsF2T-s",
      },
      {
        title: "Martial Arts Showdown",
        src: "https://www.youtube.com/watch?v=M7XM597XO94",
      },
    ],
    Comedy: [
      {
        title: "Hilarious Misunderstanding",
        src: "https://www.youtube.com/watch?v=kn271kr_ks0",
      },
      {
        title: "Office Pranks Gone Wild",
        src: "https://www.youtube.com/watch?v=1aHtJZXqgU4",
      },
      {
        title: "Awkward First Date",
        src: "https://www.youtube.com/watch?v=q0e7Zf7jMPE",
      },
      {
        title: "Family Vacation Chaos",
        src: "https://www.youtube.com/watch?v=5iaYLCiq5RM",
      },
    ],
    Drama: [
      {
        title: "Emotional Reunion",
        src: "https://www.youtube.com/watch?v=413KGp9VDkY",
      },
      {
        title: "Courtroom Confrontation",
        src: "https://www.youtube.com/watch?v=ej3ioOneTy8",
      },
      {
        title: "Tragic Love Story",
        src: "https://www.youtube.com/watch?v=1JBxpdQCH9c",
      },
      {
        title: "Family Secret Revealed",
        src: "https://www.youtube.com/watch?v=Y_oXLOuYarQ",
      },
    ],
    Documentary: [
      {
        title: "Wonders of the Ocean",
        src: "https://www.youtube.com/watch?v=6zrn4-FfbXw",
      },
      {
        title: "Space Exploration",
        src: "https://www.youtube.com/watch?v=GoW8Tf7hTGA",
      },
      {
        title: "Ancient Civilizations",
        src: "https://www.youtube.com/watch?v=5YdIXNhKAU4",
      },
      {
        title: "Climate Change Impact",
        src: "https://www.youtube.com/watch?v=yiw6_JakZFc",
      },
    ],
  };

  categories.forEach((category) => {
    const button = document.createElement("button");
    button.textContent = category;
    button.classList.add("btn");
    button.addEventListener("click", () => {
      categoryButtons
        .querySelectorAll(".btn")
        .forEach((btn) => btn.classList.remove("active"));
      button.classList.add("active");
      loadVideos(category);
    });
    categoryButtons.appendChild(button);
  });

  function loadVideos(category) {
    videoContainer.innerHTML = "";
    const videos = videoData[category];

    if (!videos) {
      videoContainer.innerHTML = "<p>No videos found for this category.</p>";
      return;
    }

    videos.forEach((video) => {
      const videoCard = videoCardTemplate.content.cloneNode(true);

      const videoElement = videoCard.querySelector("video");
      videoElement.src = video.src;

      const titleElement = videoCard.querySelector("h3");
      titleElement.textContent = video.title;

      const commentForm = videoCard.querySelector(".comment-form");
      commentForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const comment = this.querySelector(".comment-box").value.trim();
        if (comment) {
          // Here you would typically send this to your backend
          console.log(`New comment for "${video.title}": ${comment}`);
          this.reset();
          alert("Comment submitted!");
        } else {
          alert("Please enter a comment before submitting.");
        }
      });

      videoContainer.appendChild(videoCard);
    });
  }

  // Load default videos (Action category)
  categoryButtons.querySelector(".btn").classList.add("active");
  loadVideos("Action");
});
